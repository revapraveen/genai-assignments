# API Automation Framework
**Stack:** Java 17 · REST Assured · Cucumber BDD · TestNG · Maven · GitHub Actions · Extent Reports

## Structure
- `src/main/java/com/framework/config`    — ConfigManager, EnvironmentConfig
- `src/main/java/com/framework/utils`     — RequestBuilder, ResponseValidator, JsonUtils, ExtentReportManager
- `src/main/java/com/framework/auth`      — AuthHelper (OAuth2/JWT)
- `src/main/java/com/framework/pojo`      — Request/Response POJOs
- `src/test/java/com/framework/stepdefs` — Cucumber step definitions
- `src/test/java/com/framework/runners`   — TestNG Cucumber runner
- `src/test/java/com/framework/hooks`     — Before/After hooks
- `src/test/resources/features`           — Gherkin feature files
- `src/test/resources/testdata`           — JSON test data files
- `src/test/resources/schemas`            — JSON schema files for validation
- `src/test/resources/config`             — Environment properties (sit/dev)

## Run Tests
```bash
# Smoke tests on SIT
mvn test -Dcucumber.filter.tags="@smoke" -Denv=sit

# Regression on DEV
mvn test -Dcucumber.filter.tags="@regression" -Denv=dev

# Full suite
mvn test -Denv=sit
```

## Reports
Extent HTML report generated at: `reports/extent/APITestReport.html`
