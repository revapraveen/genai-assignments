package com.framework.utils;

import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import org.testng.Assert;

/** Centralised response validation utilities. */
public class ResponseValidator {
    public static void assertStatusCode(Response response, int expected) {
        Assert.assertEquals(response.getStatusCode(), expected,
                "Status code mismatch. Response: " + response.getBody().asString());
    }

    public static void assertSchema(Response response, String schemaPath) {
        response.then().assertThat()
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath(schemaPath));
    }

    public static void assertResponseTime(Response response, long maxMs) {
        Assert.assertTrue(response.getTime() <= maxMs,
                "Response time " + response.getTime() + "ms exceeded " + maxMs + "ms");
    }
}
