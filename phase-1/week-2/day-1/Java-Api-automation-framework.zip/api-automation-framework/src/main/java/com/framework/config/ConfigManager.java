package com.framework.config;

import java.io.FileInputStream;
import java.util.Properties;

/**
 * Singleton ConfigManager — loads environment-specific properties.
 * Usage: ConfigManager.getInstance().get("base.url")
 */
public class ConfigManager {
    private static ConfigManager instance;
    private final Properties props = new Properties();

    private ConfigManager() {
        String env = System.getProperty("env", "sit");
        try (FileInputStream fis = new FileInputStream(
                "src/test/resources/config/" + env + ".properties")) {
            props.load(fis);
        } catch (Exception e) {
            throw new RuntimeException("Failed to load config for env: " + env, e);
        }
    }

    public static synchronized ConfigManager getInstance() {
        if (instance == null) instance = new ConfigManager();
        return instance;
    }

    public String get(String key) { return props.getProperty(key); }
}
