package com.framework.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

/** Singleton Extent Reports manager. */
public class ExtentReportManager {
    private static ExtentReports extent;
    private static final ThreadLocal<ExtentTest> test = new ThreadLocal<>();

    public static ExtentReports getInstance() {
        if (extent == null) {
            ExtentSparkReporter spark = new ExtentSparkReporter("reports/extent/APITestReport.html");
            spark.config().setReportName("API Automation Report");
            spark.config().setDocumentTitle("API Test Results");
            extent = new ExtentReports();
            extent.attachReporter(spark);
            extent.setSystemInfo("Environment", System.getProperty("env", "sit"));
            extent.setSystemInfo("Framework", "REST Assured + Cucumber + TestNG");
        }
        return extent;
    }

    public static void setTest(ExtentTest extentTest) { test.set(extentTest); }
    public static ExtentTest getTest() { return test.get(); }
    public static void flush() { getInstance().flush(); }
}
