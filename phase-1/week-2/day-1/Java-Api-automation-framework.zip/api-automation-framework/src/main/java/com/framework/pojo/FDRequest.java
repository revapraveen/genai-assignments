package com.framework.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FDRequest {
    @JsonProperty("customerId")   private String customerId;
    @JsonProperty("amount")       private double amount;
    @JsonProperty("tenureMonths") private int    tenureMonths;
    @JsonProperty("interestType") private String interestType;
    @JsonProperty("nomineeId")    private String nomineeId;
}
