package com.framework.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class FDResponse {
    @JsonProperty("fdAccountNumber") private String fdAccountNumber;
    @JsonProperty("status")          private String status;
    @JsonProperty("maturityDate")    private String maturityDate;
    @JsonProperty("maturityAmount")  private double maturityAmount;
    @JsonProperty("interestRate")    private double interestRate;
}
