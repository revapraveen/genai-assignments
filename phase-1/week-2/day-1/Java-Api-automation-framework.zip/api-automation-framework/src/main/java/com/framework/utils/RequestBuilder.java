package com.framework.utils;

import com.framework.config.ConfigManager;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.specification.RequestSpecification;
import io.restassured.http.ContentType;

/**
 * Builder pattern for REST Assured RequestSpec.
 * Centralises base URL, headers, and content type.
 */
public class RequestBuilder {
    public static RequestSpecification build() {
        return new RequestSpecBuilder()
                .setBaseUri(ConfigManager.getInstance().get("base.url"))
                .setContentType(ContentType.JSON)
                .addHeader("Accept", "application/json")
                .build();
    }

    public static RequestSpecification buildWithAuth(String token) {
        return new RequestSpecBuilder()
                .setBaseUri(ConfigManager.getInstance().get("base.url"))
                .setContentType(ContentType.JSON)
                .addHeader("Authorization", "Bearer " + token)
                .addHeader("Accept", "application/json")
                .build();
    }
}
