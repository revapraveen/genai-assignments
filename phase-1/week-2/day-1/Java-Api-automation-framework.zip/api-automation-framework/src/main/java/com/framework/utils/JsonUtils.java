package com.framework.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;

/** JSON serialisation/deserialisation helpers. */
public class JsonUtils {
    private static final ObjectMapper mapper = new ObjectMapper();

    public static <T> T fromFile(String filePath, Class<T> clazz) {
        try {
            return mapper.readValue(new File(filePath), clazz);
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse JSON from: " + filePath, e);
        }
    }

    public static String toJson(Object obj) {
        try {
            return mapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException("Failed to serialise object to JSON", e);
        }
    }
}
