package com.framework.auth;

import com.framework.config.ConfigManager;
import io.restassured.RestAssured;
import io.restassured.response.Response;

/** Handles OAuth2 / JWT token generation for API authentication. */
public class AuthHelper {
    private static String cachedToken;

    public static String getToken() {
        if (cachedToken != null) return cachedToken;
        ConfigManager config = ConfigManager.getInstance();
        Response response = RestAssured
                .given()
                .baseUri(config.get("auth.url"))
                .formParam("grant_type", "client_credentials")
                .formParam("client_id", config.get("client.id"))
                .formParam("client_secret", config.get("client.secret"))
                .post("/token");
        cachedToken = response.jsonPath().getString("access_token");
        return cachedToken;
    }

    public static void resetToken() { cachedToken = null; }
}
