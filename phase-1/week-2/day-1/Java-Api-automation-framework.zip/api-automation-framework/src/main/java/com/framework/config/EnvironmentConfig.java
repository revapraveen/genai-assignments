package com.framework.config;

/** Typed accessors for common config keys. */
public class EnvironmentConfig {
    private final ConfigManager config = ConfigManager.getInstance();
    public String baseUrl()  { return config.get("base.url"); }
    public String authUrl()  { return config.get("auth.url"); }
    public int    timeout()  { return Integer.parseInt(config.get("timeout.ms")); }
}
