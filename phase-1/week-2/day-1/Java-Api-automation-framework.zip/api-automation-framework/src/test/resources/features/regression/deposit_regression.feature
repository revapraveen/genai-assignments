@regression
Feature: Fixed Deposit regression tests

  @regression @interest
  Scenario Outline: FD interest calculation for various tenures
    Given a valid FD creation request for customer "<customerId>" with amount <amount> for <months> months
    When the FD creation API is invoked
    Then the response status code should be 201
    And the maturity amount should reflect correct interest for <months> months

    Examples:
      | customerId | amount   | months |
      | CUST001    | 100000.0 | 12     |
      | CUST002    | 250000.0 | 24     |
      | CUST003    | 500000.0 | 36     |
