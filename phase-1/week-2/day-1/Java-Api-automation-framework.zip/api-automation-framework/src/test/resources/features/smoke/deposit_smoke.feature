@smoke
Feature: Fixed Deposit creation smoke tests

  Background:
    Given the banking API is available

  Scenario: Successful FD creation with valid inputs
    Given a valid FD creation request for customer "CUST001" with amount 50000.0 for 12 months
    When the FD creation API is invoked
    Then the response status code should be 201
    And the FD account number should be returned

  Scenario: FD creation fails with zero amount
    Given a valid FD creation request for customer "CUST001" with amount 0.0 for 12 months
    When the FD creation API is invoked
    Then the response status code should be 400
