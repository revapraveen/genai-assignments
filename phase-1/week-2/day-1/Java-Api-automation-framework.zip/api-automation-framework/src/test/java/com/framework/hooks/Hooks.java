package com.framework.hooks;

import com.framework.utils.ExtentReportManager;
import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hooks {
    @Before
    public void beforeScenario(Scenario scenario) {
        var test = ExtentReportManager.getInstance().createTest(scenario.getName());
        ExtentReportManager.setTest(test);
        test.info("Tags: " + scenario.getSourceTagNames());
    }

    @After
    public void afterScenario(Scenario scenario) {
        if (scenario.isFailed()) {
            ExtentReportManager.getTest().fail("Scenario failed: " + scenario.getName());
        } else {
            ExtentReportManager.getTest().pass("Scenario passed");
        }
    }

    @AfterAll
    public static void afterAll() { ExtentReportManager.flush(); }
}
