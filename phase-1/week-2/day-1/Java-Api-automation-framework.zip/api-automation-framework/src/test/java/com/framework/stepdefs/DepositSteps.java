package com.framework.stepdefs;

import com.framework.auth.AuthHelper;
import com.framework.pojo.FDRequest;
import com.framework.pojo.FDResponse;
import com.framework.utils.RequestBuilder;
import com.framework.utils.ResponseValidator;
import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;

public class DepositSteps {
    private Response response;
    private FDRequest fdRequest;

    @Given("a valid FD creation request for customer {string} with amount {double} for {int} months")
    public void buildFDRequest(String customerId, double amount, int months) {
        fdRequest = FDRequest.builder()
                .customerId(customerId)
                .amount(amount)
                .tenureMonths(months)
                .interestType("COMPOUND")
                .build();
    }

    @When("the FD creation API is invoked")
    public void invokeCreateFD() {
        response = RestAssured
                .given().spec(RequestBuilder.buildWithAuth(AuthHelper.getToken()))
                .body(fdRequest)
                .post("/fd/create");
    }

    @Then("the response status code should be {int}")
    public void assertStatusCode(int statusCode) {
        ResponseValidator.assertStatusCode(response, statusCode);
    }

    @Then("the FD account number should be returned")
    public void assertFDAccountNumber() {
        FDResponse fdResponse = response.as(FDResponse.class);
        Assert.assertNotNull(fdResponse.getFdAccountNumber(), "FD account number should not be null");
    }
}
